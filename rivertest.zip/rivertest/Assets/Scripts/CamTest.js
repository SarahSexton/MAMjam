﻿var cam1 : GameObject;
var cam2 : GameObject;
var cam3 : GameObject;
var cam4 : GameObject;
var cam5 : GameObject;
var cam6 : GameObject;

function Update()
{
	if (Input.GetKeyDown("1"))
	{
		cam1.SetActive(true);
		cam2.SetActive(false);
		cam3.SetActive(false);
		cam4.SetActive(false);
		cam5.SetActive(false);
		cam6.SetActive(false);
	}
	if (Input.GetKeyDown("2"))
	{
		cam2.SetActive(true);
		cam1.SetActive(false);
		cam3.SetActive(false);
		cam4.SetActive(false);
		cam5.SetActive(false);
		cam6.SetActive(false);
	}
	if (Input.GetKeyDown("3"))
	{
		cam3.SetActive(true);
		cam1.SetActive(false);
		cam2.SetActive(false);
		cam4.SetActive(false);
		cam5.SetActive(false);
		cam6.SetActive(false);
	}
	if (Input.GetKeyDown("4"))
	{
		cam4.SetActive(true);
		cam1.SetActive(false);
		cam2.SetActive(false);
		cam3.SetActive(false);
		cam5.SetActive(false);
		cam6.SetActive(false);
	}
	if (Input.GetKeyDown("5"))
	{
		cam5.SetActive(true);
		cam1.SetActive(false);
		cam2.SetActive(false);
		cam3.SetActive(false);
		cam4.SetActive(false);
		cam6.SetActive(false);
	}
	if (Input.GetKeyDown("6"))
	{
		cam6.SetActive(true);
		cam1.SetActive(false);
		cam2.SetActive(false);
		cam3.SetActive(false);
		cam4.SetActive(false);
		cam5.SetActive(false);
	}
}